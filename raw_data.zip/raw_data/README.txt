Forearm data is data from the preliminary EMG tests showing how some movements can be isolated by placing the electrodes along specific muscles. 

Hold and Pinch use the same electrode placements shown in the pictures. 

The pinch was done by bringing the thumb to the index and middle finger and squeezing in a periodic fashion for 30 s. 

The hold was done by bringing the thumb to the index and middle finger and squeezing continuously if possible for 60 s. Due to inconsistencies in experimental procedure in the latter half of measurement and inconsistencies in start time, only the period from 5s to 35s was used for analysis. 