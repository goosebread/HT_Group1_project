Electrodes were attached approximately on top of the muscles indicated in the title. flextion, extention, radial deviation, ulnar deviation, pronation, and supination were repeated two times per movement in that order. 

A time domain display is all that is needed to see which motions are picked up well and which ones are rejected/not measured for each position. 

Unfortunately, the original pictures documenting the electrode placement has been lost. For any attempts to reproduce these findings, consult an anatomy reference.